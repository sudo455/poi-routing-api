#!/usr/bin/env python3
"""Application entry point."""
import os
from app import create_app

app = create_app(os.getenv('FLASK_CONFIG', 'development'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
